

#pragma GCC target ("thumb")
#include <stdbool.h>
#include "sam.h"
#include "ld19.h"
#include "uart_print_api.c"
#define PACKET_COUNT 100

void print_lidardata(LiDARFrameTypeDef *);

void GCLK_setup();
void initializeSystemFor48MHz();
void PORT_setup();
void USART_setup();
void DIR_setup() {//in1~4 ���� ����
	PORT->Group[0].DIRSET.reg = (1 << 14) | (1 << 9) | (1 << 8) | (1 << 15);//2,3,4,5 port
}

int Distance();
void TC3_setup();//���ʹ���
void TC4_setup();
int main()
{
	unsigned count, msg_size;
	char msg[] = {"Hello World!"};
	char rx_data;
	char speed_low, start_angle_low, end_angle_low, timestamp_low, distance_low;
	_Bool	led, rxc_flag, started;
	unsigned num_packet, uart_count, npoint, offset;
	
	LiDARFrameTypeDef ld19packet[PACKET_COUNT];
	
	/* Initialize the SAM system */
	SystemInit();
	
	initializeSystemFor48MHz();
	
	GCLK_setup();
	USART_setup();
	
	PORT_setup();
	

	DIR_setup();

	TC3_setup();
	TC4_setup();

	//
	// Send 'Hello World' message
	//
	num_packet = 0;
	count = 0;
	msg_size = sizeof(msg);
	
	while (1) {
		if (SERCOM5->USART.INTFLAG.bit.DRE == 1) {
			if (count == msg_size) {
				SERCOM5->USART.DATA.reg	= 10; // Line Feed
				while (!SERCOM5->USART.INTFLAG.bit.DRE); // wait until data register is empty
				SERCOM5->USART.DATA.reg	= 13; // Carriage Return
				break;
				} else {
				SERCOM5->USART.DATA.reg	= msg[count];
				count++;
			}
		}
	};

	//
	// Syncing ld19 packets...
	//
	num_packet = 0;
	uart_count = 0;
	started = 0;
	
	while(1) {
		rxc_flag = SERCOM2->USART.INTFLAG.bit.RXC; // check out RXC (Receive Complete) flag
		if (rxc_flag == 1)	{
			rx_data	= SERCOM2->USART.DATA.reg; // Read the received data
			//SERCOM5->USART.DATA.reg	= rx_data; // Write the received data (echo back to PC)

			switch (uart_count)
			{
				case 1:	ld19packet[num_packet].ver_len = rx_data;
				break;
				case 2: speed_low = rx_data;
				break;
				case 3: ld19packet[num_packet].speed = (uint16_t) ((rx_data << 8) | speed_low);
				break;
				case 4: start_angle_low = rx_data;
				break;
				case 5: ld19packet[num_packet].start_angle = (uint16_t) ((rx_data << 8) | speed_low);
				break;
				case 6 ... 41:
				npoint = (uart_count - 6) / 3 ;
				offset = (uart_count - 6) % 3 ;
				if      (offset == 0) distance_low = rx_data;
				else if (offset == 1) ld19packet[num_packet].point[npoint].distance =
				(uint16_t) ((rx_data << 8) | distance_low);
				else if (offset == 2) ld19packet[num_packet].point[npoint].intensity =
				(uint8_t) rx_data;
				break;
				case 42: end_angle_low = rx_data;
				break;
				case 43: ld19packet[num_packet].end_angle = (uint16_t) ((rx_data << 8) | end_angle_low);
				break;
				case 44: timestamp_low = rx_data;
				break;
				case 45: ld19packet[num_packet].timestamp = (uint16_t) ((rx_data << 8) | timestamp_low);
				break;
				case 46: break;
				default: break;
			}

			//
			// * Trying to sync by finding out the header (0x54) and VerLen (0x2C)
			// * Note that it is not perfectly syncing though.
			// * There is a slim chance (1 out of 2^16) of falsely syncing
			//
			// * uart_count: count from HEADER to CRC check (47 bytes)
			if ((uart_count == 1) & rx_data == 0x2C) { // VerLen: 0x2C
				uart_count++;
				started = 1;
				if ((rx_data == PKG_HEADER) && (SERCOM2->USART.DATA.reg == 0x2C)) {
					uart_count = 2;
					started = 1;
				}
				} else if (started & (uart_count > 0) & (uart_count < (packet_len-1))) {
				uart_count++;
				} else if (started & (uart_count == (packet_len-1))) {
				started = 0;
				uart_count = 0;
				} else if (rx_data == PKG_HEADER) { // header: 0x54
				uart_count = 0;
				uart_count++;
			}
			int front_distance_cm = 300;
			int right_distance_cm = 300;
			int left_distance_cm = 300;
			if (num_packet == PACKET_COUNT) {

				int left_distance_cm_before = 400;//노이즈 방지용
				int right_distance_cm_before = 400;//노이즈 방지용
				for (int k = 0; k < PACKET_COUNT; k++) {
					float s = ld19packet[k].start_angle / 100.0;
					float e = ld19packet[k].end_angle / 100.0;
					
					for (int i = 0; i < 12; i++) {
						float diff = e - s;
						if (diff < 0) diff += 360.0;
						
						int angle = s;
						angle = angle % 360;
						//print_string("A=", sizeof("A="));
						//print_unsigned_int((int)(angle * 100));
						//print_enter();
						uint16_t d = (ld19packet[k].point[0].distance/10);
						if (angle >= 345.0 || angle <= 15.0) {
							if (d > 0 && d < front_distance_cm)
							front_distance_cm = d;
							
						}
						
						else if (angle >= 80 && angle <= 100) { // 오른쪽

							if ((d > 5 && d < 300 && (abs(d - right_distance_cm) <= 15)) || right_distance_cm <= 300)
							{


								right_distance_cm = d;
							}


						}
						else if (angle >= 260 && angle <= 280) { // 왼쪽

							if ((d > 5 && d < 300 && (abs(d - left_distance_cm) <= 15) || left_distance_cm <= 300))
							{
								
								left_distance_cm = d;
							}
							

							

							
						}
					}
				}

				//print_lidardata(ld19packet);
				print_string("Front = ", sizeof("Front = "));
				print_unsigned_int(front_distance_cm);
				print_enter();

				print_string("Right = ", sizeof("Right = "));
				print_unsigned_int(right_distance_cm);
				print_enter();

				print_string("Left  = ", sizeof("Left  = "));
				print_unsigned_int(left_distance_cm);
				print_enter();
				

				num_packet = 0;


				//라이더 분석 완료
				//
				PORT->Group[0].OUT.reg = 0 << 7 ;
				
				RTC_setup();
				
				while (RTC->MODE0.INTFLAG.bit.CMP0 != 1) ;

				RTC->MODE0.INTFLAG.bit.CMP0 = 1; // clear overflow interrupt flag
				PORT->Group[0].OUT.reg = 1 << 7;

				while (RTC->MODE0.INTFLAG.bit.CMP0 != 1) ;

				RTC->MODE0.INTFLAG.bit.CMP0 = 1; // clear overflow interrupt flag
				PORT->Group[0].OUT.reg = 0 << 7 ;
				// --------------------------------------------

				// Now use RTC to measure the pulse width of echo input.
				RTC->MODE0.CTRL.bit.ENABLE = 0; // Disable first
				RTC->MODE0.CTRL.bit.MATCHCLR = 0; // Now just count...
				RTC->MODE0.COUNT.reg = 0x0; // initialize the counter to 0
				RTC->MODE0.CTRL.bit.ENABLE = 1; // Enable

				int dist = Distance();
				if (front_distance_cm < dist) dist = front_distance_cm;

					if (dist <= 11) {
						set_backward();
						TC3->COUNT16.CC[1].reg = 470;
						TC4->COUNT16.CC[1].reg = 470;
						while (TC4->COUNT16.STATUS.bit.SYNCBUSY);

					}
					else if ((left_distance_cm < right_distance_cm && dist <= 16 && right_distance_cm < 500) || left_distance_cm < 14){
						set_forward();
						TC3->COUNT16.CC[1].reg = 700;
						TC4->COUNT16.CC[1].reg = 0;

					}
					else if ((left_distance_cm > right_distance_cm && dist <= 16 && left_distance_cm < 500) || right_distance_cm < 13 ) {
						set_forward();
						TC3->COUNT16.CC[1].reg = 0;
						TC4->COUNT16.CC[1].reg = 700;

					}
					
					else
					{
						if (right_distance_cm < left_distance_cm && (right_distance_cm > 23 && right_distance_cm < 100 )){
							set_forward();
							TC3->COUNT16.CC[1].reg = 650;
							TC4->COUNT16.CC[1].reg = 0;
							for(volatile int i = 0; i < 100000; i++);
							TC3->COUNT16.CC[1].reg = 500;
							TC4->COUNT16.CC[1].reg = 500;							
						
						else if (right_distance_cm > left_distance_cm && (left_distance_cm > 2 && left_distance_cm < 100)){
							set_forward();
							TC3->COUNT16.CC[1].reg = 0;
							TC4->COUNT16.CC[1].reg = 650;
						}	
						else if(front_distance_cm < 20){
							set_forward();
							TC3->COUNT16.CC[1].reg = 500;
							TC4->COUNT16.CC[1].reg = 500;							
						}
						else{							
						set_forward();
						TC3->COUNT16.CC[1].reg = 750;
						TC4->COUNT16.CC[1].reg = 750;
						while (TC4->COUNT16.STATUS.bit.SYNCBUSY);
						}
						
						
					}
					
					left_distance_cm_before = left_distance_cm;
					right_distance_cm_before = right_distance_cm;
				

				}
			}
			
			else if (uart_count == (packet_len-1)) {
				num_packet++;
			}
			
		};

	}; // end of while

	return (0);
}

void set_forward() {
	PORT->Group[0].OUTSET.reg = 1 << 14;
	PORT->Group[0].OUTSET.reg = 1 << 8;
	PORT->Group[0].OUTCLR.reg = 1 << 9;
	PORT->Group[0].OUTCLR.reg = 1 << 15;

}
void set_backward(){
	PORT->Group[0].OUTCLR.reg = 1 << 14;
	PORT->Group[0].OUTCLR.reg = 1 << 8;
	PORT->Group[0].OUTSET.reg = 1 << 9;
	PORT->Group[0].OUTSET.reg = 1 << 15;
}

void print_lidardata(LiDARFrameTypeDef * ld19data) {
	
	uint16_t speed, start_angle, end_angle, distance;
	unsigned char speed_msg[] = " speed = ";
	unsigned char startangle_msg[] = " start angle = ";
	unsigned char endangle_msg[] = " end angle = ";
	unsigned char point_msg[] = " point = ";
	int i;
	
	for (i=0; i<PACKET_COUNT; i++) {
		print_string(speed_msg, sizeof(speed_msg));
		speed = ld19data[i].speed;
		print_unsigned_int(speed);

		print_string(startangle_msg, sizeof(startangle_msg));
		start_angle = ld19data[i].start_angle;
		print_unsigned_int(start_angle);

		print_string(endangle_msg, sizeof(endangle_msg));
		end_angle = ld19data[i].end_angle;
		print_unsigned_int(end_angle);

		print_string(point_msg, sizeof(point_msg));
		distance = ld19data[i].point[0].distance;
		print_unsigned_int(distance);

		print_enter();
	}
}


void GCLK_setup() {
	
	// OSC8M
	//SYSCTRL->OSC8M.bit.ENABLE = 0; // Disable
	SYSCTRL->OSC8M.bit.PRESC = 0;  // prescalar to 1
	SYSCTRL->OSC8M.bit.ONDEMAND = 0;
	//SYSCTRL->OSC8M.bit.ENABLE = 1; // Enable
	
	// Power Manager
	PM->APBCMASK.bit.SERCOM5_ = 1 ; // Clock Enable (APBC clock)
	PM->APBCMASK.bit.SERCOM2_ = 1 ; // Clock Enable (APBC clock)
	
	//
	// * Generator #2 is taking the clock source #6 (OSC8M: 8MHz clock input) as an input
	//
	GCLK->GENCTRL.bit.ID = 2; // Generator #2
	GCLK->GENCTRL.bit.SRC = 6; // OSC8M
	GCLK->GENCTRL.bit.OE = 1 ;  // Output Enable: GCLK_IO
	GCLK->GENCTRL.bit.GENEN = 1; // Generator Enable

	GCLK->GENDIV.bit.ID = 1 ; // Generator #1 to check DIV value in debugger

	//
	// * SERCOM5: USART
	// * Generator #2 is feeding USART as well
	//
	GCLK->CLKCTRL.bit.ID = 0x19; // ID #0x19 (SERCOM5: USUART)
	GCLK->CLKCTRL.bit.GEN = 2; // Generator #2 selected for USART
	GCLK->CLKCTRL.bit.CLKEN = 1; // Now, clock is supplied to USART!

	//
	// * SERCOM2: USART
	// * Generator #2 is feeding USART as well
	//
	GCLK->CLKCTRL.bit.ID = 0x16; // ID #0x16 (SERCOM2: USUART)
	GCLK->CLKCTRL.bit.GEN = 2; // Generator #2 selected for USART
	GCLK->CLKCTRL.bit.CLKEN = 1; // Now, clock is supplied to USART!
	GCLK->GENCTRL.bit.ID = 0; // Generator #0
	GCLK->GENCTRL.bit.SRC = 6; // OSC8M
	GCLK->GENCTRL.bit.OE = 1 ;  // Output Enable: GCLK_IO
	GCLK->GENCTRL.bit.GENEN = 1; // Generator Enable
	
	GCLK->CLKCTRL.bit.ID = 4; // ID #4 (RTC)
	GCLK->CLKCTRL.bit.GEN = 0; // Generator #0 selected for RTC
	GCLK->CLKCTRL.bit.CLKEN = 1; // Now, clock is supplied to RTC!
	
	GCLK->CLKCTRL.bit.ID = 0x1B; // ID #ID (TCC2, TC3)
	GCLK->CLKCTRL.bit.GEN = 0; // Generator #0 selected for TCC2, TC3
	GCLK->CLKCTRL.bit.CLKEN = 1; // Now, clock is supplied to TCC2, TC3
	
	GCLK->CLKCTRL.bit.ID = 0x1C; // ID #ID (TC4, TC5)
	GCLK->CLKCTRL.bit.GEN = 0; // Generator #0 selected for TC4, TC5
	GCLK->CLKCTRL.bit.CLKEN = 1; // Now, clock is supplied to TC4, TC5
	while (GCLK->STATUS.bit.SYNCBUSY);

}


void initializeSystemFor48MHz()
{
	// Change the timing of the NVM access
	NVMCTRL->CTRLB.bit.RWS = NVMCTRL_CTRLB_RWS_HALF_Val; // 1 wait state for operating at 2.7-3.3V at 48MHz.

	// Enable the bus clock for the clock system.
	//PM->APBAMASK.bit.GCLK_ = true;
	PM->APBAMASK.bit.GCLK_ = 1;

	// Initialise the DFLL to run in closed-loop mode at 48MHz
	// 1. Make a software reset of the clock system.
	//GCLK->CTRL.bit.SWRST = true;
	GCLK->CTRL.bit.SWRST = 1;
	while (GCLK->CTRL.bit.SWRST && GCLK->STATUS.bit.SYNCBUSY) {};
	// 2. Make sure the OCM8M keeps running.
	SYSCTRL->OSC8M.bit.ONDEMAND = 0;
	
	// 3. Set the division factor to 64, which reduces the 1MHz source to 15.625kHz
	GCLK->GENDIV.reg =
	GCLK_GENDIV_ID(3) | // Select generator 3
	GCLK_GENDIV_DIV(64); // Set the division factor to 64
	
	// 4. Create generic clock generator 3 for the 15KHz signal of the DFLL
	GCLK->GENCTRL.reg =
	GCLK_GENCTRL_ID(3) | // Select generator 3
	GCLK_GENCTRL_SRC_OSC8M | // Select source OSC8M
	GCLK_GENCTRL_GENEN; // Enable this generic clock generator
	while (GCLK->STATUS.bit.SYNCBUSY) {}; // Wait for synchronization
	
	// 5. Configure DFLL with the
	GCLK->CLKCTRL.reg =
	//GCLK_CLKCTRL_ID_DFLL48M | // Target is DFLL48M
	0x00 | // Target is DFLL48M
	GCLK_CLKCTRL_GEN(3) | // Select generator 3 as source.
	GCLK_CLKCTRL_CLKEN; // Enable the DFLL48M
	while (GCLK->STATUS.bit.SYNCBUSY) {}; // Wait for synchronization
	
	// 6. Workaround to be able to configure the DFLL.
	//SYSCTRL->DFLLCTRL.bit.ONDEMAND = false;
	SYSCTRL->DFLLCTRL.bit.ONDEMAND = 0;
	while (!SYSCTRL->PCLKSR.bit.DFLLRDY) {}; // Wait for synchronization.
	
	// 7. Change the multiplication factor.
	SYSCTRL->DFLLMUL.bit.MUL = 3072; // 48MHz / (1MHz / 64)
	SYSCTRL->DFLLMUL.bit.CSTEP = 1; // Coarse step = 1
	SYSCTRL->DFLLMUL.bit.FSTEP = 1; // Fine step = 1
	while (!SYSCTRL->PCLKSR.bit.DFLLRDY) {}; // Wait for synchronization.
	
	// 8. Start closed-loop mode
	SYSCTRL->DFLLCTRL.reg |=
	SYSCTRL_DFLLCTRL_MODE | // 1 = Closed loop mode.
	SYSCTRL_DFLLCTRL_QLDIS; // 1 = Disable quick lock.
	while (!SYSCTRL->PCLKSR.bit.DFLLRDY) {}; // Wait for synchronization.
	
	// 9. Clear the lock flags.
	SYSCTRL->INTFLAG.bit.DFLLLCKC = 1;
	SYSCTRL->INTFLAG.bit.DFLLLCKF = 1;
	SYSCTRL->INTFLAG.bit.DFLLRDY = 1;
	
	// 10. Enable the DFLL
	//SYSCTRL->DFLLCTRL.bit.ENABLE = true;
	SYSCTRL->DFLLCTRL.bit.ENABLE = 1;
	while (!SYSCTRL->PCLKSR.bit.DFLLRDY) {}; // Wait for synchronization.
	
	// 11. Wait for the fine and coarse locks.
	while (!SYSCTRL->INTFLAG.bit.DFLLLCKC && !SYSCTRL->INTFLAG.bit.DFLLLCKF) {};
	
	// 12. Wait until the DFLL is ready.
	while (!SYSCTRL->INTFLAG.bit.DFLLRDY) {};

	// Switch the main clock speed.
	// 1. Set the divisor of generic clock 0 to 0
	GCLK->GENDIV.reg =
	GCLK_GENDIV_ID(0) | // Select generator 0
	GCLK_GENDIV_DIV(0);
	while (GCLK->STATUS.bit.SYNCBUSY) {}; // Wait for synchronization
	
	// 2. Switch generic clock 0 to the DFLL
	GCLK->GENCTRL.reg =
	GCLK_GENCTRL_ID(0) | // Select generator 0
	GCLK_GENCTRL_SRC_DFLL48M | // Select source DFLL
	GCLK_GENCTRL_IDC | // Set improved duty cycle 50/50
	GCLK_GENCTRL_GENEN; // Enable this generic clock generator
	GCLK->GENCTRL.bit.OE = 1 ;  // Output Enable: GCLK_I
	
	// Prof. Suh added start
	//GCLK->GENDIV.bit.DIV = 8 ;  // 48MHz / 8 (divided by 8), check out DIVSEL for details
	//GCLK->GENCTRL.bit.DIVSEL = 0;  //
	// Prof. Suh added end
	
	while (GCLK->STATUS.bit.SYNCBUSY) {}; // Wait for synchronization
}



void PORT_setup() {
	
	//


	// PORT setup for PB22 and PB23 (USART)
	//
	PORT->Group[1].PINCFG[22].reg = 0x41; // peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[1].PINCFG[23].reg = 0x41; // peripheral mux: DRVSTR=1, PMUXEN = 1

	PORT->Group[1].PMUX[11].bit.PMUXE = 0x03; // peripheral function D selected
	PORT->Group[1].PMUX[11].bit.PMUXO = 0x03; // peripheral function D selected

	//
	// PORT setup for PA10 and PA11 (USART): SERCOM2
	//
	PORT->Group[0].PINCFG[10].reg = 0x41; // peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[0].PINCFG[11].reg = 0x41; // peripheral mux: DRVSTR=1, PMUXEN = 1

	PORT->Group[0].PMUX[5].bit.PMUXE = 0x03; // peripheral function D selected
	PORT->Group[0].PMUX[5].bit.PMUXO = 0x03; // peripheral function D selected


	PORT->Group[0].PINCFG[7].reg = 0x0;		// PMUXEN = 0
	PORT->Group[0].DIRSET.reg = 0x1 << 7;		// Direction: Output
	PORT->Group[0].OUT.reg = 0 << 7 ;          // Set the Trigger to 0

	//
	// PORT setup for PA19 to take the echo input from Ultrasonic sensor
	//
	PORT->Group[0].PINCFG[6].reg = 0x2;		// INEN = 1, PMUXEN = 0
	PORT->Group[0].DIRCLR.reg = 0x1 << 6;		// Direction: Input

}


void USART_setup() {
	
	//
	// USART setup
	//
	SERCOM5->USART.CTRLA.bit.MODE = 1 ; // Internal Clock
	SERCOM5->USART.CTRLA.bit.CMODE = 0 ; // Asynchronous UART
	SERCOM5->USART.CTRLA.bit.RXPO = 3 ; // PAD3
	SERCOM5->USART.CTRLA.bit.TXPO = 1 ; // PAD2
	SERCOM5->USART.CTRLB.bit.CHSIZE = 0 ; // 8-bit data
	SERCOM5->USART.CTRLA.bit.DORD = 1 ; // LSB first
	//SERCOM5->USART.CTRLA.bit.SAMPR = 1 ; //

	SERCOM5->USART.BAUD.reg = 0Xc504 ; // 115,200 bps (baud rate) with 8MHz input clock
	//SERCOM5->USART.BAUD.reg = 0X8a09 ; // 230,400 bps (baud rate) with 8MHz input clock
	//SERCOM5->USART.BAUD.reg = 0Xe282 ; // 115,200 bps (baud rate) with 16MHz input clock
	//SERCOM5->USART.BAUD.reg = 0Xec57 ; // 115,200 bps (baud rate) with 24MHz input clock
	//SERCOM5->USART.BAUD.reg = 0Xf62b ; // 115,200 bps (baud rate) with 48MHz input clock

	SERCOM5->USART.CTRLB.bit.RXEN = 1 ;
	SERCOM5->USART.CTRLB.bit.TXEN = 1 ;

	SERCOM5->USART.CTRLA.bit.ENABLE = 1;
	
	//
	// USART setup: SERCOM2
	//
	SERCOM2->USART.CTRLA.bit.MODE = 1 ; // Internal Clock
	SERCOM2->USART.CTRLA.bit.CMODE = 0 ; // Asynchronous UART
	SERCOM2->USART.CTRLA.bit.RXPO = 3 ; // PAD3
	SERCOM2->USART.CTRLA.bit.TXPO = 1 ; // PAD2
	SERCOM2->USART.CTRLB.bit.CHSIZE = 0 ; // 8-bit data
	SERCOM2->USART.CTRLA.bit.DORD = 1 ; // LSB first
	//SERCOM5->USART.CTRLA.bit.SAMPR = 1 ; //

	SERCOM2->USART.BAUD.reg = 0X8a09 ; // 230,400 bps (baud rate) with 8MHz input clock
	SERCOM2->USART.CTRLB.bit.RXEN = 1 ;
	SERCOM2->USART.CTRLB.bit.TXEN = 1 ;

	SERCOM2->USART.CTRLA.bit.ENABLE = 1;
	
}



void TC3_setup() {

	//
	// PORT setup for PA18 ( TC3's WO[0] )
	//
	PORT->Group[0].PINCFG[18].reg = 0x41;		// peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[0].PMUX[9].bit.PMUXE = 0x04;	// peripheral function E selected

	//
	// PORT setup for PA19 ( TC3's WO[1] )
	//
	PORT->Group[0].PINCFG[19].reg = 0x41;		// peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[0].PMUX[9].bit.PMUXO = 0x04;	// peripheral function E selected

	// Power Manager
	PM->APBCMASK.bit.TC3_ = 1 ; // Clock Enable (APBC clock) for TC3

	//
	// TC3 setup: 16-bit Mode
	//

	TC3->COUNT16.CTRLA.bit.MODE = 0;  // Count16 mode
	TC3->COUNT16.CTRLA.bit.WAVEGEN = 3 ; // Match PWM (MPWM)
	TC3->COUNT16.CTRLA.bit.PRESCALER = 6; // Timer Counter clock 31,250 Hz = 8MHz / 256
	//TC3->COUNT16.CC[0].reg = 30000;  // CC0 defines the period
	//TC3->COUNT16.CC[1].reg = 10000;  // CC1 match pulls down WO[1]
	TC3->COUNT16.CC[0].reg = 1000;  // CC0 defines the period
	TC3->COUNT16.CC[1].reg = 200;  // CC1 match pulls down WO[1]
	TC3->COUNT16.CTRLA.bit.ENABLE = 1 ;
}


void TC4_setup() {

	//
	// PORT setup for PA22 ( TC4's WO[0] )
	//
	PORT->Group[0].PINCFG[22].reg = 0x41;		// peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[0].PMUX[11].bit.PMUXE = 0x04;	// peripheral function E selected

	//
	// PORT setup for PA23 ( TC4's WO[1] )
	//
	PORT->Group[0].PINCFG[23].reg = 0x41;		// peripheral mux: DRVSTR=1, PMUXEN = 1
	PORT->Group[0].PMUX[11].bit.PMUXO = 0x04;	// peripheral function E selected

	// Power Manager
	PM->APBCMASK.bit.TC4_ = 1 ; // Clock Enable (APBC clock) for TC3

	//
	// TC4 setup: 16-bit Mode
	//

	TC4->COUNT16.CTRLA.bit.MODE = 0;  // Count16 mode
	TC4->COUNT16.CTRLA.bit.WAVEGEN = 3 ; // Match PWM (MPWM)
	TC4->COUNT16.CTRLA.bit.PRESCALER = 6; // Timer Counter clock 31,250 Hz = 8MHz / 256

	TC4->COUNT16.CC[0].reg = 1000;  // CC0 defines the period
	TC4->COUNT16.CC[1].reg = 200;  // CC1 match pulls down WO[1]
	TC4->COUNT16.CTRLA.bit.ENABLE = 1 ;
	
}


int Distance(void)
{
	unsigned int RTC_count, count_start, count_end;
	unsigned int echo_time_interval, distance;
	
	// take the echo input from pa6
	while (!(PORT->Group[0].IN.reg & 0x00000040)) ;
	
	count_start = RTC->MODE0.COUNT.reg;

	// take the echo input from pa6
	while (PORT->Group[0].IN.reg & 0x00000040);
	
	count_end   = RTC->MODE0.COUNT.reg;
	RTC_count = count_end - count_start;
	echo_time_interval = RTC_count / 8 ; // echo interval in usec (8MHz clock input)
	distance = (echo_time_interval / 2) * 0.034 ; // distance in cm
	int dis = distance;
	print_decimal(distance / 100);
	distance = distance % 100;
	print_decimal(distance / 10);
	print_decimal(distance % 10);
	print_enter();
	return dis;
}

void RTC_setup() {
	//
	// RTC setup: MODE0 (32-bit counter) with COMPARE 0
	//
	RTC->MODE0.CTRL.bit.ENABLE = 0; // Disable first
	RTC->MODE0.CTRL.bit.MODE = 0; // Mode 0
	RTC->MODE0.CTRL.bit.MATCHCLR = 1; // match clear
	
	// 8MHz RTC clock  --> 10 usec when 80 is counted
	RTC->MODE0.COMP->reg = 80; // compare register to set up 10usec interval
	RTC->MODE0.COUNT.reg = 0x0; // initialize the counter to 0
	RTC->MODE0.CTRL.bit.ENABLE = 1; // Enable
}